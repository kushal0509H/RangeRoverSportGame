# MainScene Setup (V3)

This document describes the fully configured Unity scene with Range Rover Sport, terrain, and controls.

## Scene Hierarchy

- Main Camera
  - AudioListener
- Directional Light (Sun)
  - DayNightCycle
- Environment
  - Terrain (generated with ProceduralJungleTerrain)
  - Trees (placed procedurally)
  - WeatherController (Rain particle system attached)
- Vehicle (RangeRoverSport)
  - Mesh (with VehicleDamageSystem)
  - Rigidbody + Collider
  - VehicleController
  - Drivetrain
  - TractionStabilityControl
  - EngineAudioController (with engine sound layers)
  - AdvancedSuspension (linked to wheel colliders)
  - 4 WheelColliders (frontLeft, frontRight, rearLeft, rearRight)
- UI Canvas
  - SteeringWheel (VirtualSteeringWheel)
  - PedalThrottle (VirtualPedal)
  - PedalBrake (VirtualPedal)
  - HUD (HUDController)
  - MiniMap (RawImage fed by top-down camera)
- MiniMapCamera (MiniMapController)

## Pre-Configuration

- All scripts from V2 are attached with default parameters.
- VehicleConfig.json has been tuned for off-road performance.
- WeatherController toggles rain randomly every 2 minutes (can be modified).
- DayNightCycle rotates sun for a 5-minute day/night cycle.

## To Use

1. Import your Range Rover FBX model into `Assets/Models/RangeRover`.
2. Replace the placeholder `SUVPlaceholder.fbx` with your model in the Vehicle object.
3. Assign wheel meshes and colliders properly.
4. Assign UI elements (steering/pedals) to MobileInputBridge.
5. Play the scene in Unity to test controls and environment.

## Build

Follow ANDROID_BUILD_STEPS.txt (from V2) to build the APK.
